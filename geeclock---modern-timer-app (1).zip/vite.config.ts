import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // IMPORTANT: Replace '<YOUR_REPOSITORY_NAME>' with the actual name of your GitHub repository.
  // For example, if your repository URL is https://github.com/geeappsdev/Agent-Assist,
  // the base should be '/Agent-Assist/'.
  base: '/<YOUR_REPOSITORY_NAME>/',
})
