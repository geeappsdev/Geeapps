
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ai } from '../services/geminiService';
// Fix: Changed import type to a standard import for `Chat` to align with @google/genai guidelines.
import { Chat } from '@google/genai';
import { Icon } from './Icon';
import { Message } from '../types';

const GEE_APPS_PERSONALITY_KEY = 'geeAppsPersonality';

export const GeeApps: React.FC = () => {
    const [systemInstruction, setSystemInstruction] = useState('');
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const chatRef = useRef<Chat | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const savedPersonality = localStorage.getItem(GEE_APPS_PERSONALITY_KEY);
        if (savedPersonality) {
            setSystemInstruction(savedPersonality);
        }
    }, []);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const initializeChat = useCallback(() => {
        try {
            chatRef.current = ai.chats.create({
                model: 'gemini-2.5-flash',
                config: {
                    systemInstruction: systemInstruction || "You are a helpful assistant.",
                },
            });
            setError(null);
        } catch (e) {
            console.error("Failed to initialize chat:", e);
            setError("Failed to initialize chat session. Please check your API key and configuration.");
        }
    }, [systemInstruction]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;

        const userMessage: Message = { sender: 'user', text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);
        setError(null);

        try {
            if (!chatRef.current) {
                initializeChat();
            }
            if (!chatRef.current) {
                 throw new Error("Chat session not initialized.");
            }

            const response = await chatRef.current.sendMessage({ message: input });
            const aiMessage: Message = { sender: 'ai', text: response.text };
            setMessages(prev => [...prev, aiMessage]);
        } catch (err) {
            console.error(err);
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(`Failed to get response: ${errorMessage}`);
            setMessages(prev => prev.slice(0, -1)); // Remove user message if send fails
        } finally {
            setIsLoading(false);
        }
    };

    const handleSavePersonality = () => {
        localStorage.setItem(GEE_APPS_PERSONALITY_KEY, systemInstruction);
        // Reset chat to apply new personality on next message
        chatRef.current = null;
        setMessages([]);
        alert('Personality saved! The next conversation will use the new instructions.');
    };
    
    const handleReset = () => {
        if(window.confirm('Are you sure you want to reset the personality and clear the chat?')) {
            setSystemInstruction('');
            localStorage.removeItem(GEE_APPS_PERSONALITY_KEY);
            chatRef.current = null;
            setMessages([]);
            setError(null);
        }
    };

    return (
        <div className="bg-gray-900 border border-primary/50 rounded-lg p-4 mt-4 animate-fade-in">
            <div className="flex items-center gap-3 mb-4">
                <Icon name="robot" className="w-8 h-8 text-secondary"/>
                <h3 className="text-xl font-bold text-secondary">GeeApps: Trainable AI Core</h3>
            </div>
            
            <div>
                <label htmlFor="personality" className="block text-sm font-medium text-text-secondary mb-2">
                    AI Personality (System Instruction)
                </label>
                <textarea
                    id="personality"
                    rows={4}
                    value={systemInstruction}
                    onChange={(e) => setSystemInstruction(e.target.value)}
                    className="w-full bg-gray-800 border border-gray-600 rounded-md p-2 text-text-primary focus:ring-2 focus:ring-secondary focus:border-secondary transition"
                    placeholder="e.g., You are a pirate captain who speaks in nautical terms."
                />
                <div className="flex gap-2 mt-2">
                     <button onClick={handleSavePersonality} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 bg-secondary text-background font-semibold rounded-md hover:bg-secondary/80 transition-colors">
                        <Icon name="save" className="w-5 h-5"/>
                        Save Personality
                    </button>
                    <button onClick={handleReset} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 transition-colors">
                        <Icon name="reset" className="w-5 h-5"/>
                        Reset
                    </button>
                </div>
            </div>

            <div className="mt-4 border-t border-gray-700 pt-4">
                <div className="h-64 bg-gray-800 rounded-md p-2 overflow-y-auto flex flex-col gap-2">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-start gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xs md:max-w-md lg:max-w-lg rounded-lg px-3 py-2 ${msg.sender === 'user' ? 'bg-primary text-white' : 'bg-surface text-text-primary'}`}>
                                <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                        <div className="flex justify-start">
                             <div className="bg-surface text-text-primary rounded-lg px-3 py-2">
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-text-secondary rounded-full animate-pulse delay-75"></div>
                                    <div className="w-2 h-2 bg-text-secondary rounded-full animate-pulse delay-150"></div>
                                    <div className="w-2 h-2 bg-text-secondary rounded-full animate-pulse delay-300"></div>
                                </div>
                            </div>
                        </div>
                    )}
                    {error && <p className="text-red-400 text-sm p-2">{error}</p>}
                    <div ref={messagesEndRef} />
                </div>
                <form onSubmit={handleSendMessage} className="mt-2 flex items-center gap-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Chat with your AI..."
                        className="flex-grow bg-surface border border-gray-600 rounded-md p-2 text-text-primary focus:ring-2 focus:ring-primary focus:border-primary transition"
                        disabled={isLoading}
                    />
                    <button type="submit" disabled={isLoading || !input.trim()} className="p-2 bg-primary text-white rounded-md hover:bg-primary/80 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors">
                        <Icon name="send" className="w-5 h-5"/>
                    </button>
                </form>
            </div>
        </div>
    );
};
