import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MainContent } from './components/MainContent';
import { SettingsModal } from './components/SettingsModal';
import { ThemeName, AppSize } from './types';

const themes: Record<ThemeName, Record<string, string>> = {
  default: {
    primary: '79 70 229', // indigo-600
    secondary: '16 185 129', // emerald-500
    background: '17 24 39', // gray-900
    surface: '31 41 55', // gray-800
    'text-primary': '249 250 251', // gray-50
    'text-secondary': '156 163 175', // gray-400
  },
  ocean: {
    primary: '59 130 246', // blue-500
    secondary: '52 211 153', // emerald-400
    background: '15 23 42', // slate-900
    surface: '30 41 59', // slate-800
    'text-primary': '241 245 249', // slate-100
    'text-secondary': '148 163 184', // slate-400
  },
  sunset: {
    primary: '249 115 22', // orange-500
    secondary: '239 68 68', // red-500
    background: '28 25 23', // stone-900
    surface: '41 37 36', // stone-800
    'text-primary': '250 250 249', // stone-50
    'text-secondary': '168 162 158', // stone-400
  },
  forest: {
    primary: '34 197 94', // green-500
    secondary: '202 138 4', // yellow-500
    background: '20 30 20', // dark green
    surface: '30 46 30', // darker green
    'text-primary': '220 252 231', // green-50
    'text-secondary': '163 230 170', // green-200
  },
};


const App: React.FC = () => {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [theme, setTheme] = useState<ThemeName>('default');
  const [size, setSize] = useState<AppSize>('md');

  useEffect(() => {
    // FIX: Safely retrieve and validate theme from localStorage before setting state.
    const savedTheme = localStorage.getItem('gee-theme');
    if (savedTheme && savedTheme in themes) {
      setTheme(savedTheme as ThemeName);
    }
    // FIX: Safely retrieve and validate size from localStorage before setting state.
    const savedSize = localStorage.getItem('gee-size');
    if (savedSize && ['sm', 'md', 'lg'].includes(savedSize)) {
      setSize(savedSize as AppSize);
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const themeColors = themes[theme];
    Object.entries(themeColors).forEach(([key, value]) => {
      root.style.setProperty(`--color-${key}`, value);
    });
    localStorage.setItem('gee-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('gee-size', size);
  }, [size]);


  const handleOpenSettings = () => setIsSettingsOpen(true);
  const handleCloseSettings = () => setIsSettingsOpen(false);

  return (
    <div className="min-h-screen">
      <Header onOpenSettings={handleOpenSettings} />
      <MainContent size={size} />
      {/* Fix: Wrapped state setters in lambdas to prevent potential type inference issues. */}
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={handleCloseSettings}
        currentTheme={theme}
        // FIX: Explicitly typed the `newTheme` parameter to resolve a type inference error where it was being inferred as `unknown`.
        onThemeChange={(newTheme: ThemeName) => setTheme(newTheme)}
        currentSize={size}
        // FIX: Explicitly typed the `newSize` parameter to resolve a type inference error where it was being inferred as `unknown`.
        onSizeChange={(newSize: AppSize) => setSize(newSize)}
      />
    </div>
  );
};

export default App;
